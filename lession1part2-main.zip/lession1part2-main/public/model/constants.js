export const DEV = true;

export const COLLECTIONS = {
    THREADS: 'threads',
    REPLIES: 'replies',
}