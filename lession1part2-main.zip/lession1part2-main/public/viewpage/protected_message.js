export const html = `

<h1>Protected Area: Access Denied!</h1>

`;