export const html = `

<h1>Welcome to Awesome Discussion Forum</h1>
Please Sign In To Do:
<ul>
    <li>TO Create a New Thread</li>
    <li>TO Browse Thread</li>
    <li>TO Reply Message to Thread</li>
</ul>
No Account Yet?
<!-- Button trigger modal -->
<button type="button" class="btn btn-outline-danger" data-bs-toggle="modal" data-bs-target="#modal-create-account">
Create Account
</button>

`;